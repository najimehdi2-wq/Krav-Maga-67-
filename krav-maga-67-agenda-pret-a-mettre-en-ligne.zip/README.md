# Krav Maga 67 — Agenda partagé

## Ce que fait l'application
- calendrier/planning partagé
- prise d'une séance avec un prénom
- libération d'une séance
- espace administrateur
- ajout de séances
- données partagées entre les téléphones via Supabase
- interface adaptée aux mobiles

## Mise en ligne gratuite

### 1. Créer le projet Supabase
Créer un projet sur https://supabase.com/.
Dans SQL Editor, coller tout le contenu de `supabase.sql` et l'exécuter.

Créer ensuite le compte administrateur dans Authentication > Users > Add user.
Exemple : ton adresse e-mail + un mot de passe.

Récupérer dans Project Settings > API :
- Project URL
- anon public key

Dans `index.html`, remplacer :
REMPLACE_MOI_SUPABASE_URL
REMPLACE_MOI_SUPABASE_ANON_KEY

par ces deux valeurs.

### 2. Mettre le site en ligne
Le plus simple est Cloudflare Pages en Direct Upload.
Créer un compte Cloudflare, ouvrir Pages, puis envoyer le dossier contenant `index.html`.

Cloudflare donnera une adresse du type :
https://krav-maga-67.pages.dev

### 3. Important
La clé `anon public` peut être présente dans le navigateur. La sécurité réelle repose sur les règles RLS de Supabase.
Ne jamais mettre une clé `service_role` dans `index.html`.

## Évolution possible
- vrai compte pour chaque coach
- seuls les coaches peuvent prendre/libérer une séance
- calendrier mensuel
- répétition automatique des séances
- notifications WhatsApp/e-mail
- logo du club
- nom du lieu précis
