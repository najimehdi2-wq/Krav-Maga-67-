-- Krav Maga 67 : base Supabase
create extension if not exists pgcrypto;

create table if not exists public.entrainements (
  id uuid primary key default gen_random_uuid(),
  date date not null,
  time time not null,
  type text not null default 'Entraînement',
  place text not null default 'Strasbourg',
  responsable text null,
  created_at timestamptz not null default now()
);

alter table public.entrainements enable row level security;

-- Tout le monde peut consulter les séances.
create policy "lecture publique"
on public.entrainements for select
to anon, authenticated
using (true);

-- Pour une version simple sans compte membre :
-- n'importe qui peut prendre une séance uniquement si elle est encore libre.
create policy "prendre une séance libre"
on public.entrainements for update
to anon, authenticated
using (responsable is null)
with check (responsable is not null);

-- Seul un utilisateur connecté peut libérer une séance.
create policy "liberer une séance"
on public.entrainements for update
to authenticated
using (true)
with check (true);

-- Seuls les utilisateurs connectés peuvent ajouter une séance.
create policy "ajouter séance admin"
on public.entrainements for insert
to authenticated
with check (true);

-- Seuls les utilisateurs connectés peuvent supprimer une séance.
create policy "supprimer séance admin"
on public.entrainements for delete
to authenticated
using (true);

alter table public.entrainements replica identity full;

-- Données de démonstration
insert into public.entrainements(date,time,type,place)
values
('2026-09-15','19:00','Entraînement','Strasbourg'),
('2026-09-17','19:00','Entraînement','Strasbourg'),
('2026-09-19','10:00','Tous niveaux','Strasbourg'),
('2026-09-22','19:00','Entraînement','Strasbourg'),
('2026-09-24','19:00','Entraînement','Strasbourg');
