# Krav Maga 67

Fichiers à mettre dans le dépôt GitHub :
- `index.html` : site complet
- `supabase.sql` : structure Supabase (à exécuter une fois)
- `index-corrige.html` : copie de secours

Le site affiche automatiquement les mardis et jeudis à 19h.
L'administration permet de créer le planning partagé sur Supabase.
